from rest_framework import generics
from .models import Item
from .serializers import ItemSerialzer

class ItemListCreateAPI(generics.ListCreateAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerialzer

class ItemDetailAPI(generics.RetrieveUpdateDestroyAPIView):
    queryset = Item.objects.all()
    serializer_class = ItemSerialzer
